"""Rayye learning prototype. Actuation is SIMULATED; no hardware is accessed."""
import asyncio
import json
import os
import secrets
import sqlite3
import time
from contextlib import asynccontextmanager
from threading import RLock
from typing import Literal

from fastapi import Depends, FastAPI, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, ConfigDict, Field, model_validator

DB = os.getenv('RAYYE_DB', 'rayye.db')
TOKEN = os.getenv('RAYYE_API_TOKEN', '')
lock = RLock()
active = None
security = HTTPBearer(auto_error=False)

def auth(credentials: HTTPAuthorizationCredentials | None = Depends(security)):
    if not TOKEN or not credentials or not secrets.compare_digest(credentials.credentials, TOKEN):
        raise HTTPException(401, 'Set RAYYE_API_TOKEN and send it as a Bearer token')

def connect():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys=ON')
    return conn

def initialize():
    with connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS zones(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, mode TEXT NOT NULL,
          low REAL NOT NULL, high REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS readings(
          id INTEGER PRIMARY KEY, zone_id INTEGER REFERENCES zones(id),
          node_id TEXT, sensor_id TEXT, moisture REAL, temperature REAL,
          humidity REAL, battery REAL, received_at REAL);
        CREATE INDEX IF NOT EXISTS readings_zone_time ON readings(zone_id,received_at);
        CREATE TABLE IF NOT EXISTS events(
          id INTEGER PRIMARY KEY, zone_id INTEGER, action TEXT, reason TEXT, at REAL);
        ''')
        # Additive migration keeps existing 0.1 databases and their readings.
        columns = {r['name'] for r in db.execute('PRAGMA table_info(zones)')}
        for name, definition in {
            'stop_rule': "TEXT NOT NULL DEFAULT 'moisture'",
            'duration_seconds': 'INTEGER NOT NULL DEFAULT 30',
            'preset_id': 'INTEGER',
        }.items():
            if name not in columns:
                db.execute(f'ALTER TABLE zones ADD COLUMN {name} {definition}')
        db.executescript("""
        CREATE TABLE IF NOT EXISTS plants(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, notes TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS soils(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, notes TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS presets(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL,
          plant_id INTEGER NOT NULL REFERENCES plants(id),
          soil_id INTEGER NOT NULL REFERENCES soils(id),
          low REAL NOT NULL, high REAL NOT NULL, duration_seconds INTEGER NOT NULL,
          calibration_ref TEXT NOT NULL, source TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS weather(
          id INTEGER PRIMARY KEY, temperature_c REAL, humidity_pct REAL,
          rain_probability_pct REAL, observed_at REAL NOT NULL, source TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS advice_log(
          id INTEGER PRIMARY KEY, zone_id INTEGER NOT NULL,
          created_at REAL NOT NULL, engine TEXT NOT NULL,
          features_json TEXT NOT NULL, advice_json TEXT NOT NULL);
        """)
        if not db.execute('SELECT 1 FROM zones LIMIT 1').fetchone():
            db.executemany('INSERT INTO zones(id,name,mode,low,high) VALUES(?,?,?,?,?)',
                           [(i, f'Demo zone {i}', 'manual', 30, 55) for i in range(1,4)])

def event(zone_id, action, reason):
    with connect() as db:
        db.execute('INSERT INTO events(zone_id,action,reason,at) VALUES(?,?,?,?)',
                   (zone_id, action, reason, time.time()))

def stop(reason):
    global active
    if active:
        event(active['zone_id'], 'stop', reason)
    active = None

def zone_or_404(zone_id):
    with connect() as db:
        row = db.execute('SELECT * FROM zones WHERE id=?', (zone_id,)).fetchone()
    if not row:
        raise HTTPException(404, 'Zone not found')
    return dict(row)

def moisture(zone_id, now):
    # Latest reading per sensor within the freshness window; then average.
    with connect() as db:
        rows = db.execute('''SELECT r.* FROM readings r JOIN
          (SELECT node_id,sensor_id,MAX(id) id FROM readings WHERE zone_id=?
           GROUP BY node_id,sensor_id) latest ON r.id=latest.id''', (zone_id,)).fetchall()
    if not rows or any(now-r['received_at'] > 90 for r in rows):
        return None
    return sum(r['moisture'] for r in rows)/len(rows)

def tick(now=None):
    global active
    now = time.time() if now is None else now
    with lock:
        if active:
            z = zone_or_404(active['zone_id'])
            value = moisture(z['id'], now)
            if now >= active['ends_at']:
                stop('duration limit')
            elif active['source'] == 'auto' and (value is None or (z['stop_rule'] == 'moisture' and value >= z['high'])):
                stop('stale data' if value is None else 'upper threshold reached')
            return
        with connect() as db:
            zones = db.execute("SELECT * FROM zones WHERE mode='auto' ORDER BY id").fetchall()
            for z in zones:
                last = db.execute("SELECT MAX(at) FROM events WHERE zone_id=? AND action='stop'", (z['id'],)).fetchone()[0]
                value = moisture(z['id'], now)
                if value is not None and value < z['low'] and (last is None or now-last >= 300):
                    active = dict(zone_id=z['id'], source='auto',
                                  ends_at=now+(z['duration_seconds'] if z['stop_rule']=='duration' else 60))
                    event(z['id'], 'start', 'below lower threshold')
                    break

async def controller():
    while True:
        tick()
        await asyncio.sleep(1)

@asynccontextmanager
async def lifespan(app):
    initialize()
    event(None, 'startup', 'simulator starts with pump and valves off')
    task = asyncio.create_task(controller())
    yield
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass
    with lock:
        stop('service shutdown')

app = FastAPI(title='Rayye backend prototype', version='0.2.0', lifespan=lifespan)

class StrictModel(BaseModel):
    model_config = ConfigDict(extra='forbid')

class ZoneInput(StrictModel):
    name: str = Field(min_length=1, max_length=80)
    mode: Literal['manual','auto'] = 'manual'
    low: float = Field(default=30, ge=0, le=100)
    high: float = Field(default=55, ge=0, le=100)
    stop_rule: Literal['moisture','duration'] = 'moisture'
    duration_seconds: int = Field(default=30, ge=1, le=60)
    @model_validator(mode='after')
    def thresholds(self):
        if self.low >= self.high:
            raise ValueError('low must be less than high')
        return self

class Reading(StrictModel):
    zone_id: int
    node_id: str = Field(min_length=1, max_length=64)
    sensor_id: str = Field(min_length=1, max_length=64)
    moisture: float = Field(ge=0, le=100, allow_inf_nan=False)
    temperature: float | None = Field(default=None, ge=-40, le=100)
    humidity: float | None = Field(default=None, ge=0, le=100)
    battery: float | None = Field(default=None, ge=0, le=100)

class Watering(StrictModel):
    duration_seconds: int = Field(default=30, ge=1, le=60)

@app.get('/health')
def health():
    return {'status':'ok','hardware':'simulated'}

@app.get('/zones', dependencies=[Depends(auth)])
def zones():
    with connect() as db:
        return [dict(r) for r in db.execute('SELECT * FROM zones')]

@app.post('/zones', status_code=201, dependencies=[Depends(auth)])
def create_zone(body: ZoneInput):
    with lock, connect() as db:
        cur = db.execute('INSERT INTO zones(name,mode,low,high,stop_rule,duration_seconds) VALUES(?,?,?,?,?,?)', tuple(body.model_dump().values()))
        zone_id = cur.lastrowid
    return zone_or_404(zone_id)

@app.put('/zones/{zone_id}', dependencies=[Depends(auth)])
def update_zone(zone_id: int, body: ZoneInput):
    with lock:
        zone_or_404(zone_id)
        if active and active['zone_id'] == zone_id:
            stop('configuration changed')
        with connect() as db:
            db.execute('UPDATE zones SET name=?,mode=?,low=?,high=?,stop_rule=?,duration_seconds=?,preset_id=NULL WHERE id=?', (*body.model_dump().values(),zone_id))
    return zone_or_404(zone_id)

@app.delete('/zones/{zone_id}', dependencies=[Depends(auth)])
def delete_zone(zone_id: int):
    with lock:
        zone_or_404(zone_id)
        if active and active['zone_id'] == zone_id:
            raise HTTPException(409, 'Stop watering before deleting this zone')
        with connect() as db:
            db.execute('DELETE FROM readings WHERE zone_id=?',(zone_id,))
            db.execute('DELETE FROM zones WHERE id=?',(zone_id,))
    return {'deleted':zone_id}

@app.post('/telemetry', status_code=201, dependencies=[Depends(auth)])
def telemetry(body: Reading):
    with lock:
        zone_or_404(body.zone_id)
        with connect() as db:
            cur = db.execute('''INSERT INTO readings(zone_id,node_id,sensor_id,moisture,temperature,humidity,battery,received_at)
              VALUES(?,?,?,?,?,?,?,?)''', (*body.model_dump().values(),time.time()))
            return {'id':cur.lastrowid}

@app.get('/zones/{zone_id}/telemetry', dependencies=[Depends(auth)])
def history(zone_id: int, limit: int = 100):
    zone_or_404(zone_id)
    if not 1 <= limit <= 1000:
        raise HTTPException(422, 'limit must be 1..1000')
    with connect() as db:
        return [dict(r) for r in db.execute('SELECT * FROM readings WHERE zone_id=? ORDER BY id DESC LIMIT ?', (zone_id,limit))]

@app.post('/zones/{zone_id}/water', dependencies=[Depends(auth)])
def water(zone_id: int, body: Watering):
    global active
    with lock:
        zone_or_404(zone_id)
        if active:
            raise HTTPException(409, 'Shared pump is busy; stop current watering first')
        active = dict(zone_id=zone_id, source='manual', ends_at=time.time()+body.duration_seconds)
        event(zone_id, 'start', 'manual command')
        return dict(active)

@app.post('/stop', dependencies=[Depends(auth)])
def stop_all():
    with lock:
        # Stop also disables automatic modes to prevent immediate restart.
        with connect() as db:
            db.execute("UPDATE zones SET mode='manual'")
        stop('owner stop; automatic modes disabled')
    return {'pump_on':False,'automatic_modes_disabled':True}

@app.get('/status', dependencies=[Depends(auth)])
def status():
    with lock:
        return {'hardware':'simulated','pump_on':active is not None,
                'active':dict(active) if active else None,
                'zones':[dict(z,moisture=moisture(z['id'],time.time())) for z in zones()]}

@app.get('/events', dependencies=[Depends(auth)])
def events():
    with connect() as db:
        return [dict(r) for r in db.execute('SELECT * FROM events ORDER BY id DESC LIMIT 100')]

# Explicit start/stop actions let the UI show one button without an unsafe toggle
# that could reverse itself when a network request is retried.
class ManualAction(StrictModel):
    action: Literal['start','stop'] = 'start'

@app.post('/zones/{zone_id}/manual', dependencies=[Depends(auth)])
def manual_button(zone_id: int, body: ManualAction = ManualAction()):
    global active
    with lock:
        z = zone_or_404(zone_id)
        if body.action == 'stop':
            with connect() as db:
                db.execute("UPDATE zones SET mode='manual' WHERE id=?", (zone_id,))
            if active and active['zone_id'] == zone_id:
                stop('manual button stop; zone automatic mode disabled')
            return {'zone_id':zone_id,'watering':False,'mode':'manual'}
        if active:
            if active['zone_id'] == zone_id:
                return dict(active) # repeated start does not extend the deadline
            raise HTTPException(409, 'Shared pump is busy')
        active = dict(zone_id=zone_id,source='manual',ends_at=time.time()+z['duration_seconds'])
        event(zone_id, 'start', 'manual button using saved duration')
        return dict(active)

class CatalogEntry(StrictModel):
    name: str = Field(min_length=1, max_length=80)
    notes: str = Field(default='', max_length=2000)

class Preset(StrictModel):
    name: str = Field(min_length=1, max_length=80)
    plant_id: int
    soil_id: int
    low: float = Field(ge=0, le=100)
    high: float = Field(ge=0, le=100)
    duration_seconds: int = Field(default=30, ge=1, le=60)
    calibration_ref: str = Field(min_length=1, max_length=500)
    source: str = Field(min_length=1, max_length=1000)
    @model_validator(mode='after')
    def thresholds(self):
        if self.low >= self.high:
            raise ValueError('low must be less than high')
        return self

def catalog_item(table, item_id):
    # table is an internal constant, never user input.
    with connect() as db:
        row = db.execute(f'SELECT * FROM {table} WHERE id=?',(item_id,)).fetchone()
    if row is None:
        raise HTTPException(404, f'{table} entry not found')
    return dict(row)

def catalog_list(table):
    with connect() as db:
        return [dict(r) for r in db.execute(f'SELECT * FROM {table} ORDER BY id')]

def catalog_create(table, body):
    with connect() as db:
        cur = db.execute(f'INSERT INTO {table}(name,notes) VALUES(?,?)',(body.name,body.notes))
        item_id=cur.lastrowid
    return catalog_item(table,item_id)

@app.get('/plants', dependencies=[Depends(auth)])
def plants():
    return catalog_list('plants')

@app.post('/plants', status_code=201, dependencies=[Depends(auth)])
def add_plant(body: CatalogEntry):
    return catalog_create('plants',body)

@app.get('/soils', dependencies=[Depends(auth)])
def soils():
    return catalog_list('soils')

@app.post('/soils', status_code=201, dependencies=[Depends(auth)])
def add_soil(body: CatalogEntry):
    return catalog_create('soils',body)

@app.get('/presets', dependencies=[Depends(auth)])
def presets():
    return catalog_list('presets')

@app.post('/presets', status_code=201, dependencies=[Depends(auth)])
def add_preset(body: Preset):
    with lock:
        catalog_item('plants',body.plant_id)
        catalog_item('soils',body.soil_id)
        with connect() as db:
            cur=db.execute('''INSERT INTO presets(name,plant_id,soil_id,low,high,
              duration_seconds,calibration_ref,source) VALUES(?,?,?,?,?,?,?,?)''',tuple(body.model_dump().values()))
            item_id=cur.lastrowid
    return catalog_item('presets',item_id)

@app.post('/zones/{zone_id}/presets/{preset_id}', dependencies=[Depends(auth)])
def apply_preset(zone_id: int, preset_id: int):
    with lock:
        zone_or_404(zone_id)
        preset=catalog_item('presets',preset_id)
        if active and active['zone_id']==zone_id:
            stop('preset changed')
        with connect() as db:
            # Explicit review/re-enable required; applying a profile cannot start water.
            db.execute('''UPDATE zones SET low=?,high=?,duration_seconds=?,preset_id=?,mode='manual'
              WHERE id=?''',(preset['low'],preset['high'],preset['duration_seconds'],preset_id,zone_id))
    return zone_or_404(zone_id)

class Weather(StrictModel):
    temperature_c: float = Field(ge=-60, le=70)
    humidity_pct: float = Field(ge=0, le=100)
    rain_probability_pct: float = Field(ge=0, le=100)
    observed_at: float = Field(gt=0)
    source: str = Field(min_length=1, max_length=500)

@app.post('/weather', status_code=201, dependencies=[Depends(auth)])
def add_weather(body: Weather):
    if body.observed_at > time.time()+60:
        raise HTTPException(422, 'Weather timestamp cannot be in the future')
    with connect() as db:
        cur=db.execute('''INSERT INTO weather(temperature_c,humidity_pct,rain_probability_pct,observed_at,source)
          VALUES(?,?,?,?,?)''',tuple(body.model_dump().values()))
        return {'id':cur.lastrowid}

@app.post('/zones/{zone_id}/advice', dependencies=[Depends(auth)])
def advice(zone_id: int):
    """Log an explainable baseline and inputs for later ML evaluation, never actuate."""
    with lock:
        z=zone_or_404(zone_id)
        value=moisture(zone_id,time.time())
        with connect() as db:
            weather=db.execute('SELECT * FROM weather ORDER BY observed_at DESC,id DESC LIMIT 1').fetchone()
        weather=dict(weather) if weather else None
        fresh_weather=weather is not None and time.time()-weather['observed_at']<=3600
        preset=catalog_item('presets',z['preset_id']) if z['preset_id'] else None
        features={'zone':z,'moisture':value,'preset':preset,'weather':weather,'weather_fresh':fresh_weather}
        if value is None:
            suggestion='Check sensors; moisture data is missing or stale.'
        elif value < z['low']:
            suggestion='Moisture is below the configured lower threshold; watering may be needed.'
        elif value >= z['high']:
            suggestion='Moisture is at or above the configured upper threshold; avoid additional watering.'
        else:
            suggestion='Moisture is inside the configured band; monitor before watering.'
        notes=['Advice only: this response never changes thresholds or actuates hardware.',
               'Thresholds must match the sensor/substrate calibration; catalog values are user supplied.']
        if not fresh_weather:
            notes.append('Weather is missing or older than one hour; refresh it before weather-based advice.')
        else:
            notes.append('Weather is recorded as context only; no validated weather-response model is implemented.')
        if not preset:
            notes.append('No plant/soil preset assigned.')
        result={'engine':'rules-v1','ml_trained':False,'suggestion':suggestion,'notes':notes,'features':features}
        with connect() as db:
            cur=db.execute('''INSERT INTO advice_log(zone_id,created_at,engine,features_json,advice_json)
              VALUES(?,?,?,?,?)''',(zone_id,time.time(),'rules-v1',json.dumps(features),json.dumps(result)))
            result['id']=cur.lastrowid
        return result
