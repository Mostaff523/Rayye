# Rayye backend prototype — 0.2

A runnable learning prototype for one Raspberry Pi installation. **All pump/valve states are simulated.** No BLE or serial hardware is accessed. Remote hosting, Flutter integration, real login, schedules and device provisioning are not implemented yet.

See [the 0.2 update](docs/UPDATE_0_2.md) for plant/soil catalogs, preset application, selectable automatic stop rules, the manual button API and the rules-based advice foundation. No ML model is trained yet.

## Run

Use Python 3.10+ from this folder:

```bash
python -m venv .venv
# Linux / Pi:
source .venv/bin/activate
# Windows PowerShell instead:
# .venv\Scripts\Activate.ps1
pip install -r requirements.txt
# Linux / Pi: choose your own long random token
export RAYYE_API_TOKEN='replace-with-your-own-long-random-token'
# PowerShell instead:
# $env:RAYYE_API_TOKEN='replace-with-your-own-long-random-token'
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000/docs and select Authorize; paste your token. Interactive docs may need internet to load their Swagger assets. The API and local database work without internet. Do not expose this development server publicly. Run exactly one worker; controller state and locking are process-local.

Three placeholder zones are created on an empty database, initially in manual mode. `rayye.db` persists zones, readings and events. Active watering is deliberately not resumed after a restart.

## Try it in /docs

1. GET /zones.
2. POST /telemetry with the sample below.
3. GET /status and GET /zones/1/telemetry.
4. POST /zones/1/water with `{"duration_seconds": 10}`. Inspect /status, then inspect after 10 seconds.
5. PUT /zones/1 with `{"name":"Demo pot","mode":"auto","low":30,"high":55}`. A fresh dry reading starts a simulated cycle.
6. POST /stop stops watering and sets every zone to manual. Re-enable auto explicitly when ready.

```json
{"zone_id":1,"node_id":"esp32-1","sensor_id":"soil-1","moisture":25,"temperature":27,"humidity":60,"battery":85}
```

Telemetry percentages are calibrated values, not raw ADC percentages. Battery is optional percent, temperature is Celsius. Each telemetry message represents one moisture sensor with optional environmental readings. Timestamps are server receipt times (UTC Unix seconds). Offline backlog ingestion is not yet supported; do not forward old measurements as live readings.

## Structure and request flow

- app/main.py: request models, token check, API routes, SQLite storage and simulated control loop. Kept together for the first lesson; split into routers/services/repositories when the behavior is agreed.
- tests/test_backend.py: isolated database and behavior checks.
- docs/DECISIONS.md: scope, defaults, questions and six-week milestones.
- docs/HARDWARE_CONTRACT.md: proposed BLE and serial interfaces for the firmware teams.

Flutter sends HTTP request -> FastAPI validates token/body -> route reads/writes SQLite -> response returns JSON. Separately, the local controller checks fresh sensor data every second and updates simulated pump/valve state.

## Implemented endpoints

Public: GET /health. All remaining routes require `Authorization: Bearer YOUR_TOKEN`.

- GET/POST /zones; PUT/DELETE /zones/{id}. PUT replaces configuration.
- POST /telemetry; GET /zones/{id}/telemetry?limit=100 (maximum 1000).
- POST /zones/{id}/water; POST /stop.
- GET /status; GET /events (latest 100).

## Default control policy (see 0.2 update for selectable stop rules)

One zone at a time on the shared pump. By default auto starts below 30%, stops at 55%, stops at 60 seconds, and waits at least 300 seconds after a stop before another auto cycle. These are demonstration values, not agronomic recommendations. Latest moisture from each previously reporting sensor in a zone is averaged; if any is older than 90 seconds the zone cannot auto-water. Explicit expected-sensor registration is still needed: a sensor that has never reported is currently invisible. Manual timed watering works without sensor readings and returns to normal auto evaluation afterward, respecting cooldown. Busy commands return 409; no queue. Zone IDs are logical IDs, not relay pins.

## Before real hardware

Implement registered devices and expected sensors, calibrated thresholds, bounded telemetry retention, separate device credentials, login if required, network/TLS deployment, backups, command ACKs and hardware watchdogs. A Pi shutdown handler cannot protect against power loss. The Arduino must independently expire every watering command and stop on heartbeat loss. Do not connect this simulator directly to relays.

## Tests

```bash
python -m pytest -q
```

Requirements pin the tested FastAPI version; other dependencies use bounded ranges. A fully locked deployment environment will follow hardware/OS confirmation.
