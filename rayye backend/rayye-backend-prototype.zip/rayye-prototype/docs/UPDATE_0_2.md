# 0.2 — plant/soil presets, stop rules, manual button and advice foundation

Confirmed: manual and moisture-triggered automatic modes. Automatic start is always below the lower moisture threshold. Choose `stop_rule: "moisture"` to stop at the upper threshold (still capped at 60 seconds), or `stop_rule: "duration"` to use `duration_seconds`. The latter ignores upper-threshold changes during the cycle, but still stops on stale sensor data. This interpretation of "both options" remains subject to owner confirmation.

Limits remain provisional: 60-second hard cap, five-minute auto cooldown and 90-second stale window. They are retained pending the later limits discussion, not new finalized requirements.

## Manual app button

`POST /zones/1/manual` with no body or `{"action":"start"}` starts a cycle using the zone's saved duration. While watering, the UI sends `{"action":"stop"}` to the same endpoint. Stop disables automatic mode for this zone to avoid immediate auto restart. Duration completion leaves the configured mode unchanged. Repeated start while already active does not extend the timer. A different active zone returns 409. This is an explicit action API, not a blind toggle; UI integration remains to do. Existing /water and /stop routes remain compatible.

## Plant + soil catalogs

1. POST /plants: `{"name":"Your plant","notes":"Growth stage or other context"}`.
2. POST /soils: `{"name":"Your substrate","notes":"Composition and calibration context"}`.
3. POST /presets using their IDs and the schema in /docs. Required: name, plant_id, soil_id, low, high, calibration_ref and source. Optional duration_seconds defaults to 30.
4. POST /zones/1/presets/1 copies thresholds and duration, records preset_id and switches the zone to manual for review. Select the desired stop_rule and re-enable automatic mode explicitly.
5. GET /plants, /soils and /presets lists stored entries.

Catalogs start empty. No plant thresholds are invented. The combination preset holds thresholds because plant needs alone cannot define an uncalibrated substrate sensor reading. Percentages currently mean sensor-relative calibrated moisture, not a proven volumetric water content measurement. Values from an external source may use a different measurement basis and must not be copied blindly.

PUT /zones/{id} remains a full replacement configuration API. It clears preset_id because supplied thresholds may now be custom. Applying a preset retains the zone's current stop_rule; changing it afterward with PUT clears the preset link. Future dedicated PATCH settings can avoid this limitation. Presets are immutable snapshots for now (create/list/apply only); edit/delete catalog operations and calibration enforcement against registered sensors are not implemented.

## Weather and advice foundation

POST /weather accepts temperature_c, humidity_pct, rain_probability_pct, observed_at (UTC Unix seconds) and source. Weather is installation-wide in this version; location/indoor/outdoor context is not yet modeled. This is a manual ingestion endpoint, not a weather API integration. Data older than one hour is marked stale. Cloud rain probability is distinct from the excluded physical rain sensor.

POST /zones/{id}/advice returns an explicitly labeled `rules-v1` suggestion plus `ml_trained: false`, and logs the input snapshot. Current suggestions use fresh moisture and configured thresholds only. Weather is stored as context but does not affect advice or control. No model has been trained, no predictive accuracy is claimed, and there is no automated threshold adaptation.

To build ML later, agree a target (e.g. moisture after a watering dose), collect synchronized weather/readings, measured or estimated watering dose, growth stage and relevant outcomes, then evaluate against this rules baseline on held-out periods. Advice logs alone are not a labeled training dataset. Keep recommendations advisory until validation. Backend architecture permits a model service later without putting network-dependent inference in the local failsafe.

## Migration and tests

Startup adds the new zone fields and catalog/weather/advice tables to a 0.1 database without dropping readings. Test suite covers both stopping modes, stale-data shutdown, profile application/reference validation, button behavior, advice logging and old database migration in addition to the original tests.

## Questions for the owner

- Confirm "both": selectable moisture stop vs timed stop, or always stop at whichever occurs first?
- Confirm manual button: saved-duration cycle, or latched on until pressed again? Current implementation uses a bounded saved-duration cycle.
- Which first-demo plants, soils/substrates, and growth stages? Which sources/calibration experiments will supply the presets?
- Is the installation outdoors or indoors, and what location should weather represent?
- What should ML predict or improve, and is a suitable existing dataset available?
- Keep automatic mode after a manual stop, or require explicit re-enable as implemented?
