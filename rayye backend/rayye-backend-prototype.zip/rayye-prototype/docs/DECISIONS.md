# Rayye scope and decisions

See UPDATE_0_2.md for the latest behavior and decisions.

## Confirmed

Graduation project; six weeks; learn while building; existing Flutter screens, no backend code; ESP32/Arduino firmware in progress. Pi 4 B / 4 GB, one installation, one preconfigured owner. Remote access required, local offline failsafe required. Zones represent pots/gardens; several sensors per zone; several sensors per ESP32. Shared pump and Arduino-controlled valves. Rain excluded. Counts unknown.

## Proposed defaults, reversible

Python + FastAPI + local SQLite. Local Pi remains authoritative online and offline; remote access is an additional secure entry point, not a requirement for watering. No cloud database dependency in v0.1. Three placeholder zones; one active zone; manual plus moisture auto; schedules later. Thirty-second sampling, 90-second stale window, mean of sensors, 60-second cycle cap, five-minute cooldown. These are test defaults requiring calibration. Retain raw history for 30 days eventually; retention/export not implemented yet. Use polling from Flutter initially. Plant/soil catalogs and configurable presets are implemented in 0.2; weather ingestion and a rules-based advisory baseline are present. Weather API integration, ML predictions and notifications remain future work. API token is prototype authentication, not an owner login.

The README architecture originally proposed Node/MongoDB. This prototype intentionally explores Python/SQLite because the owner knows Python and the Pi already needs Python hardware services. The stack choice remains open.

## Decisions needed next

1. Actual weekly deliverables, grading constraints, and any mandated stack.
2. GitHub repository for Flutter, its state-management approach, and whether login stays.
3. Whether remote access is only for the owner (private access possible) or must work for arbitrary phones without extra setup; Pi internet/router restrictions.
4. Pump/valve types, relay polarity, simultaneous-watering capability and pin map.
5. Exact sensor models, placement, calibration, and how many sensors are required per zone. Minimum/mean/median aggregation choice.
6. Required automatic/manual/schedule behavior and owner stop/resume expectations.
7. First-demo counts, sensor update interval, charts/time ranges and measured vs estimated water use. Flow sensor is not confirmed, so water-volume statistics cannot be treated as measured.
8. Whether temperature/humidity sensors send independent samples; current prototype requires moisture per message.

## Proposed six-week milestones

Week 1: agree scope/contracts; run API, CRUD and simulated telemetry; inspect Flutter repo.
Week 2: owner access, device registration/mapping, calibration fields; connect Flutter dashboard.
Week 3: BLE ingestion and real sensor history, stale detection and reconnect handling.
Week 4: serial commands/ACKs/watchdog, manual watering and tested shared-pump sequencing.
Week 5: automatic control, offline/network-loss tests and secure remote access.
Week 6: integration fixes, documentation, backups and demonstration rehearsal.

Replace these milestones with the actual weekly deadlines when supplied. No live public deployment has been performed.
