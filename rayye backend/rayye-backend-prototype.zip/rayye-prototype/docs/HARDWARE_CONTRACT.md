# Proposed hardware protocol v0 — agreement needed before firmware integration

## ESP32 -> Pi, BLE GATT notification

Recommended logical message (transport fragmentation/MTU negotiation still to implement):

```json
{"v":1,"node_id":"esp32-1","sequence":42,"samples":[{"sensor_id":"soil-1","zone_id":1,"moisture_pct":25.0,"temperature_c":27.0,"humidity_pct":60.0,"battery_pct":85.0}]}
```

One node can report sensors from several zones. The Pi bridge will validate provisioned node/sensor-to-zone mappings, deduplicate sequence numbers within a boot session (add boot_id in firmware), and convert samples into POST /telemetry bodies. This bridge is not implemented in v0.1. Never trust arbitrary client zone mappings in the production bridge. Confirm GATT service/characteristic UUIDs together; none are assigned yet. Never assume this JSON fits a single BLE notification: choose negotiated MTU plus framing/chunks or a compact binary format together. Proposed sampling interval: 30 seconds; 90-second stale window.

## Pi -> Arduino, USB serial

Proposed 115200 baud, newline-delimited JSON; commands have unique IDs and bounded deadlines.

```json
{"v":1,"id":"cmd-001","op":"water","zone_id":1,"duration_ms":30000}
{"v":1,"id":"cmd-002","op":"stop_all"}
{"v":1,"id":"hb-001","op":"heartbeat"}
```

Proposed response:

```json
{"v":1,"id":"cmd-001","ok":true,"pump_on":true,"open_zones":[1]}
```

ACK means firmware applied the output state; it does not prove water is flowing. The eventual backend must report desired and acknowledged states separately. On timeout, status is unknown and the bridge must request stop, not claim physical success. Firmware rejects unknown zones and duplicate watering IDs (duplicates must not extend timers), enforces one open zone, limits duration to 60 seconds, and boots with all outputs off. Pi heartbeat every 1 second; Arduino stops everything after 3 seconds without heartbeat. Reconnect begins with stop_all and state reconciliation; no replay of old start commands.

Valve open -> pump on; pump off -> valve close. Confirm actual delays, relay polarity, pump/valve electrical interfaces and hydraulic requirements with the hardware team. Pin mapping remains unassigned. None of this serial protocol is implemented by the simulator yet.
