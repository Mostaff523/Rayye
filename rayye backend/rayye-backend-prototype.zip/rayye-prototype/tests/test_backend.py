import time
import pytest
from fastapi.testclient import TestClient
from app import main as m

@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setattr(m, 'DB', str(tmp_path/'test.db'))
    monkeypatch.setattr(m, 'TOKEN', 'test-token')
    m.active = None
    with TestClient(m.app) as c:
        c.headers['Authorization'] = 'Bearer test-token'
        yield c

def reading(client, sensor='soil-1', moisture=20):
    return client.post('/telemetry', json=dict(zone_id=1,node_id='esp32-1',sensor_id=sensor,moisture=moisture))

def test_auth_and_validation(client):
    assert client.get('/zones', headers={'Authorization':'Bearer wrong'}).status_code == 401
    assert client.post('/telemetry',json=dict(zone_id=999,node_id='a',sensor_id='b',moisture=20)).status_code == 404
    assert client.post('/telemetry',json=dict(zone_id=1,node_id='a',sensor_id='b',moisture=101)).status_code == 422
    assert client.put('/zones/1',json=dict(name='Pot',low=70,high=30)).status_code == 422

def test_crud_and_persistence(client):
    z=client.post('/zones',json={'name':'Mint'}).json()
    assert client.put(f"/zones/{z['id']}",json={'name':'Basil'}).json()['name']=='Basil'
    reading(client)
    assert client.get('/zones/1/telemetry').json()[0]['moisture']==20
    assert client.delete(f"/zones/{z['id']}").status_code==200

def test_manual_interlock_and_expiry(client):
    assert client.post('/zones/1/water',json={'duration_seconds':1}).status_code==200
    assert client.post('/zones/2/water',json={}).status_code==409
    assert client.delete('/zones/1').status_code==409
    m.tick(time.time()+2)
    assert client.get('/status').json()['pump_on'] is False

def test_auto_stale_stop_and_cooldown(client):
    reading(client)
    client.put('/zones/1',json=dict(name='Pot',mode='auto'))
    m.tick()
    assert m.active['source']=='auto'
    m.tick(time.time()+61)
    assert m.active is None
    m.tick()
    assert m.active is None # cooldown prevents immediate repeated watering
    client.post('/stop')
    assert client.get('/zones').json()[0]['mode']=='manual'

def test_multi_sensor_and_upper_threshold(client):
    reading(client, 'soil-1',10)
    reading(client, 'soil-2',30)
    assert client.get('/status').json()['zones'][0]['moisture']==20
    client.put('/zones/1',json=dict(name='Pot',mode='auto'))
    m.tick()
    reading(client,'soil-1',80)
    reading(client,'soil-2',80)
    m.tick()
    assert m.active is None
    with m.connect() as db:
        db.execute('UPDATE readings SET received_at=?',(time.time()-100,))
    assert client.get('/status').json()['zones'][0]['moisture'] is None

def test_preset_application_and_missing_references(client):
    plant=client.post('/plants',json={'name':'Test plant'}).json()
    soil=client.post('/soils',json={'name':'Test substrate'}).json()
    payload=dict(name='Lab only',plant_id=plant['id'],soil_id=soil['id'],low=25,high=50,
                 duration_seconds=12,calibration_ref='lab calibration A',source='synthetic test fixture')
    assert client.post('/presets',json=dict(payload,plant_id=999)).status_code==404
    preset=client.post('/presets',json=payload).json()
    client.put('/zones/1',json=dict(name='Pot',mode='auto'))
    z=client.post(f"/zones/1/presets/{preset['id']}").json()
    assert (z['low'],z['high'],z['duration_seconds'],z['mode'])==(25,50,12,'manual')
    assert z['preset_id']==preset['id']
    assert client.get('/plants').json()[0]['name']=='Test plant'
    assert client.get('/soils').json()[0]['name']=='Test substrate'
    assert client.post('/presets',json=dict(payload,low=80,high=10)).status_code==422

def test_duration_stop_rule_and_stale_data(client):
    client.put('/zones/1',json=dict(name='Pot',mode='auto',stop_rule='duration',duration_seconds=20))
    reading(client)
    m.tick()
    deadline=m.active['ends_at']
    reading(client,moisture=90)
    m.tick()
    assert m.active is not None # duration mode ignores upper threshold
    m.tick(deadline+1)
    assert m.active is None
    # Safety stale check applies even to duration mode.
    with m.connect() as db:
        db.execute('DELETE FROM events')
    reading(client,moisture=10)
    m.tick()
    with m.connect() as db:
        db.execute('UPDATE readings SET received_at=?',(time.time()-100,))
    m.tick()
    assert m.active is None

def test_button_uses_saved_duration_and_does_not_extend(client):
    client.put('/zones/1',json=dict(name='Pot',duration_seconds=12))
    first=client.post('/zones/1/manual').json()
    assert 10 < first['ends_at']-time.time() <=12
    assert client.post('/zones/1/manual').json()['ends_at']==first['ends_at']
    assert client.post('/zones/2/manual').status_code==409
    assert client.post('/zones/1/manual',json={'action':'stop'}).json()['watering'] is False
    assert m.active is None

def test_advice_records_context_without_actuation(client):
    reading(client)
    assert client.post('/weather',json=dict(temperature_c=30,humidity_pct=40,
        rain_probability_pct=80,observed_at=time.time(),source='test weather')).status_code==201
    result=client.post('/zones/1/advice').json()
    assert result['engine']=='rules-v1' and result['ml_trained'] is False
    assert result['features']['weather_fresh'] is True
    assert m.active is None
    with m.connect() as db:
        assert db.execute('SELECT COUNT(*) FROM advice_log').fetchone()[0]==1

def test_migration_preserves_old_database(tmp_path,monkeypatch):
    import sqlite3
    path=str(tmp_path/'old.db')
    with sqlite3.connect(path) as db:
        db.execute('CREATE TABLE zones(id INTEGER PRIMARY KEY,name TEXT NOT NULL,mode TEXT NOT NULL,low REAL NOT NULL,high REAL NOT NULL)')
        db.execute("INSERT INTO zones VALUES(1,'Original','manual',20,40)")
    monkeypatch.setattr(m,'DB',path)
    m.initialize()
    m.initialize() # migration is repeatable
    z=m.zone_or_404(1)
    assert z['name']=='Original' and z['stop_rule']=='moisture'
